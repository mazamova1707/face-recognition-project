
import face_recognition
import cv2

image = face_recognition.load_image_file("example.jpg")
face_locations = face_recognition.face_locations(image)

print(f"Найдено лиц: {len(face_locations)}")
