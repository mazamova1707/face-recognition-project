
# Face Recognition Project

Проект по распознаванию лиц на Python с использованием `face_recognition` и `opencv-python`.

## Установка зависимостей
```
pip install -r requirements.txt
```

## Использование
### Распознавание на фото:
```
python face_from_image.py
```

### Распознавание с камеры:
```
python face_from_camera.py
```

## Пример
Пример изображения находится в файле `example.jpg`.
